#version 120

#define ENCHANT_GLINT

#include "/dimensions/clrwl_glint.fsh"